
const handleTransaction = async (amount, connection, publicKey, toast, balance,) => {
    if (!connection || !publicKey) {
      toast({
        variant: "destructive",
        title: "Uh oh! Something went wrong.",
        description: "Please Connect your wallet and try again",
      })
      return;
    }
  
    if (amount < 0.01 || amount === 0 || amount === null) {
      toast({
        variant: "destructive",
        title: "Invalid Amount",
        description: "Please enter a valid amount. Minimum Purchase is 0.01 SOl",
      })
      return;
    }
    if(balance < amount || balance === 0 || balance === amount ){
      toast({
        variant: "destructive",
        title: "Insufficient Balance",
        description: `Your ${balance} Sol is currently insufficent. Top up your balance to purchase presale`,
      })
      return
    }
    const transaction = new web3.Transaction();
    const instruction = web3.SystemProgram.transfer({
      fromPubkey: publicKey,
      lamports: amount * web3.LAMPORTS_PER_SOL,
      toPubkey: TokenAddress,
    });
  
    transaction.add(instruction);
   
    try {
      const signature = await sendTransaction(transaction, connection);
      setTxSig(signature)
      console.log()
      sendTokens(amountTokens, publicKey)
      toast({
        title: "Deposit Successful!",
        description: "Your token will appear in your wallet soon..",
      })
    }
    catch (error) {
      console.log(error);
      toast({
        variant: "destructive",
        title: "Transaction Failed",
        description: "There was a problem with your request.",
      })
    }
  };